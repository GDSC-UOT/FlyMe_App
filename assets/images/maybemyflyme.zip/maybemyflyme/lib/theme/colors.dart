import 'package:flutter/material.dart';
Color primaryColor=const Color(0xFF8BB1EE);
Color white=Colors.white;
Color emptyColor=Colors.transparent;
